USE [CONTACT_MANAGER] 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
--drop table [Supplier]
CREATE TABLE [Supplier](
	[SupplierId] int IDENTITY(1,1) PRIMARY KEY, 
	[PersonId] [BIGINT] NOT NULL,
	[Telephone] varchar(12) NOT NULL /*CHECK(DATALENGTH(Telephone)>=7)*/)
GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [Supplier]  WITH CHECK ADD FOREIGN KEY([PersonId])
REFERENCES [Person] ([ID])
GO

ALTER TABLE [Supplier]
ADD CONSTRAINT validTelephone CHECK([Telephone] NOT LIKE '^\d{7}|\d{8}|\d{9}|\d{10}$')
GO



