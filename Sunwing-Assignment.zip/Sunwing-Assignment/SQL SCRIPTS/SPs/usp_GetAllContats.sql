IF OBJECT_ID ('usp_GetAllContats', 'P' ) IS NOT NULL   
    DROP PROCEDURE usp_GetAllContats;  
GO 
CREATE PROC usp_GetAllContats    
AS  
BEGIN TRAN
	BEGIN TRY 
		SELECT Person.ID, Person.FirstName,Person.LastName, Customer.BirthDay, Customer.Email, '' AS Telephone
		FROM Person 
		INNER JOIN Customer ON
		Person.Id = Customer.PersonId
		UNION
		SELECT Person.ID, Person.FirstName,Person.LastName,'', '', supplier.Telephone
		FROM Person 
		INNER JOIN Supplier ON
		Person.Id = Supplier.PersonId
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
	DECLARE @ErrorMessage NVARCHAR(4000);
	 DECLARE @ErrorSeverity INT;
	 DECLARE @ErrorState INT;
	
	SELECT 
		 @ErrorMessage = ERROR_MESSAGE(),
		 @ErrorSeverity = ERROR_SEVERITY(),
		 @ErrorState = ERROR_STATE();
	
	RAISERROR (@ErrorMessage, @ErrorSeverity,@ErrorState)
END CATCH
