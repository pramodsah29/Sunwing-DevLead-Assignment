IF OBJECT_ID ('usp_DeleteContatById', 'P' ) IS NOT NULL   
    DROP PROCEDURE usp_DeleteContatById;  
GO 
CREATE PROC usp_DeleteContatById
	@Id BIGINT    
AS  
BEGIN TRAN
	BEGIN TRY 
		DELETE FROM Supplier where personID = @Id
		DELETE FROM Customer where personID = @Id
		DELETE FROM Person where Id = @Id
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
	DECLARE @ErrorMessage NVARCHAR(4000);
	 DECLARE @ErrorSeverity INT;
	 DECLARE @ErrorState INT;
	
	SELECT 
		 @ErrorMessage = ERROR_MESSAGE(),
		 @ErrorSeverity = ERROR_SEVERITY(),
		 @ErrorState = ERROR_STATE();
	
	RAISERROR (@ErrorMessage, @ErrorSeverity,@ErrorState)
END CATCH
