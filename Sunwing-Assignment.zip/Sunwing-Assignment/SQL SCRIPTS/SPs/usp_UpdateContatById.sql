IF OBJECT_ID ('usp_UpdateContatById', 'P' ) IS NOT NULL   
    DROP PROCEDURE usp_UpdateContatById;  
GO 
CREATE PROC usp_UpdateContatById
	@Id BIGINT,
	@FirstName VARCHAR(50),
	@LastName VARCHAR(50),
	@BirthDay DATETIME,
	@Email VARCHAR(250),
	@Telephone VARCHAR(10)    
AS  
BEGIN TRAN
	BEGIN TRY 
		UPDATE Supplier SET
			Telephone = @Telephone
			where PersonID = @Id
		
		UPDATE Customer SET
			Birthday = @BirthDay,
			Email = @Email
			where PersonID = @Id
			
		UPDATE Person SET
			FirstName = @FirstName,
			LastName = @LastName
			where Id = @Id
			
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
	DECLARE @ErrorMessage NVARCHAR(4000);
	 DECLARE @ErrorSeverity INT;
	 DECLARE @ErrorState INT;
	
	SELECT 
		 @ErrorMessage = ERROR_MESSAGE(),
		 @ErrorSeverity = ERROR_SEVERITY(),
		 @ErrorState = ERROR_STATE();
	
	RAISERROR (@ErrorMessage, @ErrorSeverity,@ErrorState)
END CATCH
