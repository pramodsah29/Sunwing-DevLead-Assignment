IF OBJECT_ID ('usp_AddContat', 'P' ) IS NOT NULL   
    DROP PROCEDURE usp_AddContat;  
GO 
CREATE PROC usp_AddContat
	@Id BIGINT OUTPUT,
	@FirstName VARCHAR(50),
	@LastName VARCHAR(50),
	@BirthDay DATETIME,
	@Email VARCHAR(250),
	@Telephone VARCHAR(10)    
AS  
BEGIN TRAN
	BEGIN TRY 
		SELECT @Id =(ISNULL(MAX(Id),0)+1) FROM [Person]
		
		INSERT INTO [Person]
           ([Id]
           ,[FirstName]
           ,[LastName])
		VALUES
           (@Id
           ,@FirstName
           ,@LastName)
	
		IF (LTRIM(RTRIM(@Telephone)) <> '')
		BEGIN
			INSERT INTO [Supplier]
			   ([PersonId]
			   ,[Telephone])
			VALUES
			   (@Id
			   ,@Telephone)
		END
		ELSE IF (LTRIM(RTRIM(@Email)) <> '')
		BEGIN
			INSERT INTO [CONTACT_MANAGER].[dbo].[Customer]
			   ([PersonId]
			   ,[Birthday]
			   ,[Email])
			VALUES
			   (@Id
			   ,@BirthDay
			   ,@Email)
		END
		
			
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
	DECLARE @ErrorMessage NVARCHAR(4000);
	 DECLARE @ErrorSeverity INT;
	 DECLARE @ErrorState INT;
	
	SELECT 
		 @ErrorMessage = ERROR_MESSAGE(),
		 @ErrorSeverity = ERROR_SEVERITY(),
		 @ErrorState = ERROR_STATE();
	
	RAISERROR (@ErrorMessage, @ErrorSeverity,@ErrorState)
END CATCH
