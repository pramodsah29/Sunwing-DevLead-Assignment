IF OBJECT_ID ('usp_GetContatById', 'P' ) IS NOT NULL   
    DROP PROCEDURE usp_GetContatById;  
GO 
CREATE PROC usp_GetContatById
	@Id BIGINT    
AS  
BEGIN TRAN
	BEGIN TRY 
		SELECT Person.ID, Person.FirstName,Person.LastName, Customer.BirthDay, Customer.Email, '' AS Telephone
		FROM Person 
		INNER JOIN Customer ON
		Person.Id = Customer.PersonId
		WHERE Person.Id = @Id
		UNION
		SELECT Person.ID, Person.FirstName,Person.LastName,'', '', supplier.Telephone
		FROM Person 
		INNER JOIN Supplier ON
		Person.Id = Supplier.PersonId
		WHERE Person.Id = @Id
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
	DECLARE @ErrorMessage NVARCHAR(4000);
	 DECLARE @ErrorSeverity INT;
	 DECLARE @ErrorState INT;
	
	SELECT 
		 @ErrorMessage = ERROR_MESSAGE(),
		 @ErrorSeverity = ERROR_SEVERITY(),
		 @ErrorState = ERROR_STATE();
	
	RAISERROR (@ErrorMessage, @ErrorSeverity,@ErrorState)
END CATCH
