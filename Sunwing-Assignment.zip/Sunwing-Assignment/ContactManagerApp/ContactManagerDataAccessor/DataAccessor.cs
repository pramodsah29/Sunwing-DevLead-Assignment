﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace ContactManagerDataAccessor
{
    public class DataAccessor
    {
        public DataTable GetContacts()
        {
            DataTable dt = new DataTable();

            SqlConnection con = new SqlConnection("Data Source=  ; initial catalog= Northwind ; User Id=  ; Password=  '");

            con.Open();

            return Dt;
        }
    }
}
