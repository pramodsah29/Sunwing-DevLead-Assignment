﻿using ContactManagerApp.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Web.Http;
using ContactManagerApp.Entities;
using ContactManagerApp.DataAccessor;

namespace ContactManagerApp.Controllers.Tests
{
    [TestClass()]
    public class ContactsControllerTests
    {
        [TestMethod()]
        public void GetTest()
        {
            // Arrange
            ContactsController controller = new ContactsController();

            // Act
            HttpResponseMessage response = (HttpResponseMessage)controller.Get();

            // Assert
            List<Contact> contactList = new List<Contact>();
            Assert.IsTrue(response.TryGetContentValue<List<Contact>>(out contactList));
            Assert.AreEqual(1, contactList[0].PersonID);
        }
    }
}
