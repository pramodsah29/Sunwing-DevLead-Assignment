﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ContactManagerApp.Entities;

namespace ContactManagerApp.DataAccessor
{

    public class ContactManagerDataAccessor
    {
        public DataTable GetContacts()
        {
            try
            {
                return DbHelper.ExecuteProcedure("usp_GetAllContats");
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        internal DataTable GetContactsByID(long id)
        {
            try
            {
                SqlParameter[] parameterList = { new SqlParameter("@Id", id) };
                return DbHelper.ExecuteProcedure("usp_GetContatById", parameterList);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        internal void DeleteContacts(long id)
        {
            try
            {
                SqlParameter[] parameterList = { new SqlParameter("@Id", id) };
                DbHelper.ExecuteNonQuery("usp_DeleteContatById", parameterList);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        internal void UpdateContacts(Contact contact)
        {
            try
            {
                SqlParameter[] parameterList = {    new SqlParameter("@Id", contact.PersonID),
                                                new SqlParameter("@FirstName", contact.FirstName),
                                                new SqlParameter("@LastName", contact.LastName),
                                                new SqlParameter("@BirthDay", contact.Birthday),
                                                new SqlParameter("@Email", contact.Email),
                                                new SqlParameter("@Telephone", contact.Telephone)};
                DbHelper.ExecuteNonQuery("usp_UpdateContatById", parameterList);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        internal long AddContacts(Contact contact)
        {
            try
            {
                if (contact.Birthday == null)
                    contact.Birthday = DateTime.MinValue;
                long output;
                SqlParameter[] parameterList = { new SqlParameter{ParameterName = "@Id", SqlDbType = SqlDbType.BigInt, Direction = ParameterDirection.Output},
                                                new SqlParameter("@FirstName", contact.FirstName),
                                                new SqlParameter("@LastName", contact.LastName),
                                                new SqlParameter("@BirthDay", contact.Birthday),
                                                new SqlParameter("@Email", contact.Email),
                                                new SqlParameter("@Telephone", contact.Telephone)};
                DbHelper.ExecuteNonQuery("usp_AddContat", parameterList, out output);
                return output;
            }
            catch (Exception ex){
                throw ex;
            }
        }
    }
}