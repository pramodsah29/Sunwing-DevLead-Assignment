function contactList() {
    // Call Web API to get a list of contact
    $.ajax({
        url: '/api/Contacts/',
        type: 'GET',
        dataType: 'json',
        success: function (contacts) {
            contactListSuccess(contacts);
        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}

function contactGet(ctl) {
    // Get product id from data- attribute
    var id = $(ctl).data("id");

    // Store product id in hidden field
    $("#Id").val(id);

    // Call Web API to get a list of Person
    $.ajax({
        url: "/api/Contacts/" + id,
        type: 'GET',
        dataType: 'json',
        success: function (person) {
            contactToFields(person);

            // Change Update Button Text
            $("#updateButton").text("Update");
        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}

function contactAdd(contact) {
    $.ajax({
        url: "/api/Contacts",
        type: 'POST',
        contentType:
        "application/json;charset=utf-8",
        data: JSON.stringify(contact),
        success: function (contact) {
            contactAddSuccess(contact);
        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}

function contactUpdate(contact) {
    $.ajax({
        url: "/api/Contacts",
        type: 'PUT',
        contentType:
        "application/json;charset=utf-8",
        data: JSON.stringify(contact),
        success: function (contact) {
            contactUpdateSuccess(contact);
        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}

function contactDelete(ctl) {
    var id = $(ctl).data("id");

    $.ajax({
        url: "/api/Contacts/" + id,
        type: 'DELETE',
        success: function (person) {
            $(ctl).parents("tr").remove();
        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}

function updateClick() {
    //if (validateFormData()) {
    // Build product object from inputs
    contact = new Object();
    contact.PersonID = $("#Id").val();
    contact.FirstName = $("#First").val();
    contact.LastName = $("#Last").val();
    contact.Email = $("#Email").val();
    contact.Telephone = $("#Telephone").val();
    if ($("#rbSupplier")[0].checked)
        contact.Birthday = '12/12/2000';
    else
        contact.Birthday = $("#Birthday").val();

    if ($("#updateButton").text().trim() == "Add") {
        contactAdd(contact);
    }
    else {
        contactUpdate(contact);
    }
    //}
}
function contactListSuccess(contacts) {
    // Iterate over the collection of data
    $.each(contacts, function (index, contact) {
        if (contact.Email == '')
            contact.Birthday = '';
        // Add a row to the Contact table
        contactAddRow(contact);
    });
}

function contactAddRow(contact) {
    // Check if <tbody> tag exists, add one if not
    if ($("#contactTable tbody").length == 0) {
        $("#contactTable").append("<tbody></tbody>");
    }
    // Append row to <table>
    $("#contactTable tbody").append(
        contactBuildTableRow(contact));
}

//Click methods of the buttons to be checked
function contactBuildTableRow(contact) {
    var ret =
        "<tr>" +
        "<td>" + contact.PersonID + "</td>" +
        "<td>" + contact.FirstName + "</td>" +
        "<td>" + contact.LastName + "</td>" +

        "<td>" + contact.Birthday + "</td>" +
        "<td>" + contact.Email + "</td>" +
        "<td>" + contact.Telephone + "</td>" +
        "<td>" +
        "<button type='button' " +
        "onclick='contactGet(this);' " +
        "class='btn btn-default' " +
        "data-id='" + contact.PersonID + "'>" + "<span class='glyphicon glyphicon-pencil' />" + "</button>" + "</td >" +
        "<td>" +
        "<button type='button' " +
        "onclick='contactDelete(this);' " +
        "class='btn btn-default' " +
        "data-id='" + contact.PersonID + "'>" + "<span class='glyphicon glyphicon-trash' />" + "</button>" + "</td>" +
        "</tr>";
    return ret;
}

function handleException(request, message, error) {
    var msg = "";
    msg += "Code: " + request.status + "\n";
    msg += "Text: " + request.statusText + "\n";
    if (request.responseJSON != null) {
        msg += "Message" +
            request.responseJSON.Message + "\n";
    }
    alert(msg);
}

function contactToFields(contact) {
    if (contact[0].Email == '')
    {
        $("#rbSupplier")[0].checked = true;

        $("#Birthday")[0].disabled = true;
        $("#Email")[0].disabled = true;
        $("#Telephone")[0].disabled = false;
    }
    else if (contact[0].Telephone == '') {
        $("#rbCustomer")[0].checked = true;

        $("#Telephone")[0].disabled = true;
        $("#Birthday")[0].disabled = false;
        $("#Email")[0].disabled = false;
    }
    $("#Id").val(contact[0].PersonID);
    $("#First").val(contact[0].FirstName);
    $("#Last").val(contact[0].LastName);
    $("#Birthday").val(contact[0].Birthday);
    $("#Email").val(contact[0].Email);
    $("#Telephone").val(contact[0].Telephone);
}

function contactUpdateSuccess(person) {
    contactUpdateInTable(person);
}

function contactUpdateInTable(person) {
    formClear(); // Clear form fields

    var myTable = document.getElementById("contactTable");
    var rowCount = myTable.rows.length;
    for (var x = rowCount - 1; x > 0; x--) {
        myTable.deleteRow(x);
    }

    contactList();

    // Change Update Button Text
    $("#updateButton").text("Add");
}

function contactAddSuccess(contact) {
    contactAddRow(contact);
    formClear();
}

function formClear() {
    $("#Id").val("");
    $("#First").val("");
    $("#Last").val("");
    $("#Birthday").val("");
    $("#Email").val("");
    $("#Telephone").val("");

    $("#rbCustomer")[0].checked = true;
    $("#Telephone")[0].disabled = true;
    $("#Birthday")[0].disabled = false;
    $("#Email")[0].disabled = false;
}

function addClick() {
    formClear();
}

function radioSelected() {
    if ($("#rbCustomer")[0].checked) {
        $("#Telephone")[0].disabled = true;
        $("#Telephone").val("");
        $("#Id").val("");

        $("#Birthday")[0].disabled = false;
        $("#Email")[0].disabled = false;
    }
    if ($("#rbSupplier")[0].checked) {
        $("#Telephone")[0].disabled = false;

        $("#Birthday")[0].disabled = true;
        $("#Email")[0].disabled = true;
        $("#Birthday").val("");
        $("#Email").val("");
        $("#Id").val("");
    }
}