﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactManagerApp.Entities
{
    public class Person
    {
        public long Id { get; set; }
        public Name Name { get; set; }
    }
}