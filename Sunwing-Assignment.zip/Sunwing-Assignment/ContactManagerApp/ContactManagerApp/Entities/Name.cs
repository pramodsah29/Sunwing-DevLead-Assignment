﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactManagerApp.Entities
{
    public class Name
    {
        public string First { get; set; }
        public string Last { get; set; }
    }
}