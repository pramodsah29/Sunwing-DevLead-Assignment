﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactManagerApp.Entities
{
    public class Supplier:Person
    {
        public string Telephone { get; set; }
    }
}