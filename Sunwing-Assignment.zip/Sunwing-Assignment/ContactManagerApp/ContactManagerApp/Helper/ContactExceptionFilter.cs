﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Web.Http.Filters;
using ContactManagerApp.Helper;

namespace ContactManagerApp.ExceptionHandle
{
    public class ContactExceptionFilter : ExceptionFilterAttribute 
    {
        public override void OnException(HttpActionExecutedContext context)
        {
             string exceptionMessage = string.Empty;  
            if (context.Exception.InnerException == null)  
            {  
                exceptionMessage = context.Exception.Message;  
            }  
            else  
            {  
                exceptionMessage = context.Exception.InnerException.Message;  
            }
            //calling logger class method to log the exception for administrative purpose.
            Logger logger = new Logger();
            logger.LogWriter(exceptionMessage);

            var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)  
           {  
                Content = new StringContent("An unhandled exception was thrown by service."),
                    ReasonPhrase = "Internal Server Error.Please Contact your Administrator." 
            };  
            context.Response = response; 

        }

    }
}