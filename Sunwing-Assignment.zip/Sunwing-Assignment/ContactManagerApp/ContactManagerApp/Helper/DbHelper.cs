﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ContactManagerApp.Entities;

namespace ContactManagerApp.DataAccessor
{
    public class DbHelper
    {
        static string connecStr = ConfigurationManager.ConnectionStrings["ContactsConnectionString"].ConnectionString;

        public static DataTable ExecuteProcedure(string PROC_NAME)
        {
            try
            {
                DataTable contactsTable = new DataTable();
                using (var DbConnection = new SqlConnection(connecStr))
                {
                    DbConnection.Open();
                    SqlCommand command = new SqlCommand(PROC_NAME, DbConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    // create data adapter
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    da.Fill(contactsTable);

                }

                return contactsTable;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable ExecuteProcedure(string PROC_NAME, params object[] parameters)
        {
            try
            {
                DataTable contactsTable = new DataTable();
                using (var DbConnection = new SqlConnection(connecStr))
                {
                    DbConnection.Open();
                    SqlCommand command = new SqlCommand(PROC_NAME, DbConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(parameters);
                    // create data adapter
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    da.Fill(contactsTable);

                }

                return contactsTable;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void ExecuteNonQuery(string PROC_NAME, SqlParameter[] parameters)
        {
            try
            {
                using (var DbConnection = new SqlConnection(connecStr))
                {
                    DbConnection.Open();
                    SqlCommand command = new SqlCommand(PROC_NAME, DbConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(parameters);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void ExecuteNonQuery(string PROC_NAME,  SqlParameter[] parameters, out long output)
        {
            try
            {
                using (var DbConnection = new SqlConnection(connecStr))
                {
                    DbConnection.Open();
                    SqlCommand command = new SqlCommand(PROC_NAME, DbConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(parameters);
                    command.ExecuteNonQuery();
                    output = Convert.ToInt64(parameters[0].SqlValue.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}