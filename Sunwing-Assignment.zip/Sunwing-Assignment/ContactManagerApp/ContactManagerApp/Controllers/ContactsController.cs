﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ContactManagerApp.DataAccessor;
using ContactManagerApp.Entities;


namespace ContactManagerApp.Controllers
{
    public class ContactsController : ApiController
    {
        [HttpGet()]
        public IHttpActionResult Get()
        {
            try
            {
                IHttpActionResult ret = null;
                List<Contact> list = new List<Contact>();
                list = GetContacts();
                ret = Ok(list);
                return ret;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet()]
        public IHttpActionResult Get(int id)
        {
            try
            {
                IHttpActionResult ret = null;
                List<Contact> list = new List<Contact>();
                list = GetContactsByID(id);
                ret = Ok(list);
                return ret;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost()]
        public IHttpActionResult Post(Contact contact)
        {
            try
            {
                IHttpActionResult ret = null;
                long personID = Add(contact);

                if (personID > 0)
                {
                    contact.PersonID = personID;
                    ret = Ok(contact);
                }
                else
                {
                    ret = BadRequest();
                }
                return ret;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut()]
        public IHttpActionResult Put(Contact contact)
        {
            try
            {
                IHttpActionResult ret = null;
                if (Update(contact))
                {
                    ret = Ok(contact);
                }
                else
                {
                    ret = NotFound();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpDelete()]
        public IHttpActionResult Delete(long id)
        {
            try
            {
                IHttpActionResult ret = null;
                if (DeleteContact(id))
                {
                    ret = Ok(true);
                }
                else
                {
                    ret = NotFound();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        private List<Contact> GetContactsByID(long id)
        {
            try
            {
                ContactManagerDataAccessor dataAccessor = new ContactManagerDataAccessor();
                DataTable dt = dataAccessor.GetContactsByID(id);

                List<Contact> contactList = PopulateContactEntity(dt);

                return contactList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        private List<Contact> GetContacts()
        {
            try
            {
                ContactManagerDataAccessor dataAccessor = new ContactManagerDataAccessor();
                DataTable dt = dataAccessor.GetContacts();

                List<Contact> contactList = PopulateContactEntity(dt);

                return contactList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<Contact> PopulateContactEntity(DataTable dt)
        {
            try
            {
                var convertedList = (from rw in dt.AsEnumerable()
                                     select new Contact()
                                     {
                                         PersonID = (long)(rw["ID"]),
                                         FirstName = Convert.ToString(rw["FirstName"]),
                                         LastName = Convert.ToString(rw["LastName"]),
                                         Email = Convert.ToString(rw["Email"]),
                                         Birthday = (DateTime)(rw["BirthDay"]),
                                         Telephone = Convert.ToString(rw["Telephone"])
                                     }).ToList();

                return convertedList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private long Add(Contact contact)
        {
            try
            {
                ContactManagerDataAccessor dataAccessor = new ContactManagerDataAccessor();
                long id = dataAccessor.AddContacts(contact);

                return id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool Update(Contact contact)
        {
            try
            {
                ContactManagerDataAccessor dataAccessor = new ContactManagerDataAccessor();
                dataAccessor.UpdateContacts(contact);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool DeleteContact(long id)
        {
            try
            {
                ContactManagerDataAccessor dataAccessor = new ContactManagerDataAccessor();
                dataAccessor.DeleteContacts(id);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
