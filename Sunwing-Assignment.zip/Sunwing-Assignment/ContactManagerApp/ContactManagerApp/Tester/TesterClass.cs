﻿
using ContactManagerApp.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Web.Http;
using ContactManagerApp.Entities;
using ContactManagerApp.DataAccessor;


namespace ContactManagerApp.Tests
{
    [TestClass()]
    public class ContactsControllerTests
    {
        [TestMethod()]
        public void GetContactTest()
        {
            // Arrange
            ContactsController controller = new ContactsController();
            IHttpActionResult response; 
            List<Contact> responseList = new List<Contact>();

            // Act
            response = controller.Get();
            responseList = ((System.Web.Http.Results.OkNegotiatedContentResult<List<Contact>>)response).Content;

            // Assert
            Assert.AreEqual(1, responseList[0].PersonID);
        }

        [TestMethod()]
        public void GetContactByIdTest()
        {
            // Arrange
            ContactsController controller = new ContactsController();
            IHttpActionResult response;
            List<Contact> responseList = new List<Contact>();

            // Act
            response = controller.Get(1);
            responseList = ((System.Web.Http.Results.OkNegotiatedContentResult<List<Contact>>)response).Content;

            // Assert
            Assert.AreEqual(1, responseList[0].PersonID);
        }

        [TestMethod()]
        public void PostContactTest()
        {
            // Arrange
            ContactsController controller = new ContactsController();
            long newPersonID = 0;

            Contact newContact = new Contact();
            newContact.FirstName = "NEW Contact First Name";
            newContact.LastName = "NEW Contact Last Name";
            newContact.Telephone = "614-220-1234";
            newContact.Birthday = DateTime.Now;
            newContact.Email = "test@gmail.com";

            // Act
            controller.Post(newContact);
            newPersonID = newContact.PersonID;

            // Assert
            Assert.AreNotEqual(0, newPersonID);
        }

        [TestMethod()]
        public void PutContactTest()
        {
            // Arrange
            ContactsController controller = new ContactsController();
            long updatePersonID = 0;

            Contact updatedContact = new Contact();
            updatedContact.PersonID = 1;
            updatedContact.FirstName = "NEW Contact First Name";
            updatedContact.LastName = "NEW Contact Last Name";
            updatedContact.Telephone = "614-220-1234";
            updatedContact.Birthday = DateTime.Now;
            updatedContact.Email = "test@gmail.com";

            // Act
            controller.Put(updatedContact);
            updatePersonID = updatedContact.PersonID;

            // Assert
            Assert.AreEqual(1, updatePersonID);
        }

        [TestMethod()]
        public void DeleteContactTest()
        {
            // Arrange
            ContactsController controller = new ContactsController();
            long deletePersonID = 11;
            bool isDeleted = false;
            IHttpActionResult response;

            // Act
            response = controller.Delete(deletePersonID);
            isDeleted = (bool)(((System.Web.Http.Results.OkNegotiatedContentResult<bool>)response).Content);

            // Assert
            Assert.IsTrue(isDeleted);
        }
    }
}


